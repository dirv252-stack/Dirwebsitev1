"use client"

import { useEffect, useRef, useState } from "react"

type Message = { id: string; text: string; rating: number; timestamp: string; nickname?: string }

const sampleMessages: Message[] = [
  { id: "1", text: "Portfolio yang keren banget! Love the terminal vibe.", rating: 5, timestamp: "2h ago", nickname: "Anonymous" },
  { id: "2", text: "Respect banget bisa bikin website dari HP doang!", rating: 5, timestamp: "5h ago", nickname: "Someone" },
  { id: "3", text: "Smooth banget animasinya. Pakai framework apa?", rating: 4, timestamp: "1d ago", nickname: "Dev99" },
]

function Stars({ rating, onRate, readOnly=false }: { rating:number; onRate?:(r:number)=>void; readOnly?:boolean }) {
  const [hovered, setHovered] = useState(0)
  const display = readOnly ? rating : (hovered || rating)
  return (
    <div className="flex gap-1">
      {[1,2,3,4,5].map((star) => (
        <button key={star} type="button" disabled={readOnly} className={`text-lg transition-all ${readOnly?"cursor-default":"cursor-pointer hover:scale-110"} ${star<=display?"text-yellow-400":"text-white/20"}`} onMouseEnter={() => !readOnly&&setHovered(star)} onMouseLeave={() => !readOnly&&setHovered(0)} onClick={() => !readOnly&&onRate?.(star)}>
          {star<=display ? "★" : "☆"}
        </button>
      ))}
    </div>
  )
}

export default function AnonymousZone() {
  const [isVisible, setIsVisible]     = useState(false)
  const [messages, setMessages]       = useState<Message[]>(sampleMessages)
  const [messageText, setMessageText] = useState("")
  const [rating, setRating]           = useState(0)
  const [nickname, setNickname]       = useState("")
  const [charCount, setCharCount]     = useState(0)
  const [submitted, setSubmitted]     = useState(false)
  const [error, setError]             = useState("")
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) setIsVisible(true) }, { threshold: 0.1 })
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (e.target.value.length <= 500) { setMessageText(e.target.value); setCharCount(e.target.value.length) }
  }

  const handleSubmit = () => {
    if (!messageText.trim()) { setError("Tulis pesan dulu!"); return }
    if (rating === 0) { setError("Kasih rating dulu!"); return }
    setError("")
    const newMsg: Message = { id: Date.now().toString(), text: messageText.trim(), rating, timestamp: "Baru saja", nickname: nickname.trim() || "Anonymous" }
    setMessages([newMsg, ...messages].slice(0, 20))
    setMessageText(""); setRating(0); setNickname(""); setCharCount(0)
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 3000)
  }

  return (
    <section ref={sectionRef} id="messages" className="relative py-32 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className={`text-4xl md:text-5xl font-bold text-center mb-2 text-white tracking-wider transition-all duration-700 ${isVisible?"opacity-100 translate-y-0":"opacity-0 translate-y-8"}`}>ANONYMOUS ZONE</h2>
        <p className={`text-center text-muted-foreground mb-16 tracking-widest text-sm transition-all duration-700 delay-100 ${isVisible?"opacity-100":"opacity-0"}`}>DROP YOUR THOUGHTS — Stay hidden</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className={`glassmorphism rounded-2xl overflow-hidden transition-all duration-700 delay-200 ${isVisible?"opacity-100 translate-y-0":"opacity-0 translate-y-8"}`}>
            <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10 bg-black/30">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500" /><div className="w-2.5 h-2.5 rounded-full bg-yellow-500" /><div className="w-2.5 h-2.5 rounded-full bg-green-500" />
              <span className="ml-2 text-xs text-white/40 font-mono">anon@message:~$</span>
            </div>
            <div className="p-5 space-y-4">
              <div className="font-mono text-xs text-white/40"><span className="text-cyan-400">{">"}</span> KIRIM PESAN ANONIM</div>
              <div>
                <div className="font-mono text-xs text-white/40 mb-2"><span className="text-cyan-400">{">"}</span> pesan:</div>
                <textarea value={messageText} onChange={handleTextChange} placeholder="Tulis pesanmu... (kamu anonim!)" className="w-full h-28 bg-black/30 border border-white/10 rounded-xl p-3 text-white text-sm font-mono resize-none outline-none focus:border-cyan-500/50 transition-all placeholder-white/20" />
                <div className={`text-right text-xs mt-1 font-mono ${charCount>=450?"text-red-400":"text-white/20"}`}>{charCount}/500</div>
              </div>
              <div>
                <div className="font-mono text-xs text-white/40 mb-2"><span className="text-cyan-400">{">"}</span> rating:</div>
                <Stars rating={rating} onRate={setRating} />
              </div>
              <div>
                <div className="font-mono text-xs text-white/40 mb-2"><span className="text-cyan-400">{">"}</span> nickname (optional):</div>
                <input type="text" value={nickname} onChange={(e) => setNickname(e.target.value.slice(0,30))} placeholder="Anonymous" className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2 text-white text-sm font-mono outline-none focus:border-cyan-500/50 transition-all placeholder-white/20" />
              </div>
              {error && <p className="text-red-400 text-xs font-mono">Error: {error}</p>}
              {submitted && <p className="text-green-400 text-xs font-mono animate-fade-in-scale">✓ Pesan terkirim! Makasih!</p>}
              <button onClick={handleSubmit} className="w-full py-3 bg-cyan-500/10 border border-cyan-500/30 rounded-xl text-cyan-300 font-mono text-sm tracking-widest hover:bg-cyan-500/20 hover:border-cyan-500/60 hover:shadow-[0_0_20px_rgba(0,229,255,0.2)] transition-all duration-300 active:scale-95">KIRIM &gt;</button>
            </div>
          </div>

          <div className={`space-y-3 transition-all duration-700 delay-300 ${isVisible?"opacity-100 translate-y-0":"opacity-0 translate-y-8"}`}>
            <div className="font-mono text-xs text-white/40 mb-4"><span className="text-cyan-400">{">"}</span> PESAN TERBARU</div>
            {messages.slice(0,6).map((msg, i) => (
              <div key={msg.id} className="glassmorphism rounded-xl p-4 hover:border-cyan-500/20 transition-all duration-300" style={{ animationDelay: `${i*100}ms` }}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-cyan-400 text-xs font-mono">{msg.nickname||"Anonymous"}</span>
                  <span className="text-white/20 text-xs font-mono">{msg.timestamp}</span>
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-2">{msg.text}</p>
                <Stars rating={msg.rating} readOnly />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
