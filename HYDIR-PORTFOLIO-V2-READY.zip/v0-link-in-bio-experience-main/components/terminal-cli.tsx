"use client"

import { useEffect, useRef, useState, useCallback } from "react"

type Line = { type: "input"|"output"|"error"|"success"|"system"; content: string }

const processCommand = (input: string, history: string[]): { lines: Line[], action?: string } => {
  const cmd = input.trim().toLowerCase()
  const parts = cmd.split(" ")
  const main = parts[0]
  const out = (c: string): Line => ({ type: "output", content: c })
  const ok  = (c: string): Line => ({ type: "success", content: c })
  const err = (c: string): Line => ({ type: "error",   content: c })

  if (cmd === "clear" || cmd === "cls") return { lines: [], action: "clear" }

  if (cmd === "help" || cmd === "--help") return { lines: [out(`
╔═══════════════════════════════════════════╗
║         AVAILABLE COMMANDS                ║
╠═══════════════════════════════════════════╣
║ INFO          about, whoami, skills       ║
║               projects, contact, social   ║
║               motto, goals, hobbies       ║
║               education, story, age       ║
╠═══════════════════════════════════════════╣
║ TECH          tech, languages, frameworks ║
║               tools, learning, ai         ║
╠═══════════════════════════════════════════╣
║ PKG           pkg upgrade, pkg install    ║
║               pkg list, /hydirmenu        ║
╠═══════════════════════════════════════════╣
║ LEARN         learn html, learn css       ║
║               learn js, learn react       ║
║               learn git, learn tailwind   ║
╠═══════════════════════════════════════════╣
║ FUN           joke, quote, hack, matrix   ║
║               codm, gf, sleep, sigma      ║
║               motivate, coffee, neofetch  ║
╠═══════════════════════════════════════════╣
║ NAV           home, scroll skills         ║
║               scroll projects             ║
╠═══════════════════════════════════════════╣
║ SYSTEM        date, time, version         ║
║               stats, history, clear       ║
╠═══════════════════════════════════════════╣
║ SECRET        dirga, secret, nocap        ║
║               based, sigma, work          ║
╚═══════════════════════════════════════════╝
  Type any command!`)] }

  if (cmd === "/hydirmenu" || cmd === "menu") return { lines: [out(`
╔═══════════════════════════════════════════╗
║         HYDIR MENU SYSTEM v2.0            ║
╠═══════════════════════════════════════════╣
║  [1] INFO:  about whoami skills projects  ║
║  [2] TECH:  tech languages frameworks     ║
║  [3] FUN:   joke quote hack matrix codm   ║
║  [4] LEARN: learn html learn css learn js ║
║  [5] NAV:   home scroll skills            ║
║  [6] SYS:   date version stats neofetch   ║
║  [7] SECRET: dirga gf sigma sleep         ║
╚═══════════════════════════════════════════╝
  Type 'help' for full list`)] }

  if (cmd === "about" || cmd === "bio") return { lines: [out(`
╔═══════════════════════════════════════════╗
║           ABOUT HYDIR                     ║
╠═══════════════════════════════════════════╣
║  Name     : Hydir (Dirga)                 ║
║  Born     : 2011                          ║
║  Location : Jawa Barat, Indonesia         ║
║  Role     : Self-Taught Developer         ║
║  Device   : Vivo Y17s                     ║
║  Passion  : Web Dev, AI, Poster Design    ║
║  Status   : Student & Building            ║
╚═══════════════════════════════════════════╝
  "Ga ada yang mustahil kalo lu niat."`)] }

  if (cmd === "whoami") return { lines: [out(`  Hydir = Self-taught dev dari Jawa Barat
  = AI Explorer & Poster Designer  
  = Coding dari HP aja bisa!
  Type '/hydirmenu' to explore more!`)] }

  if (cmd === "skills" || cmd === "skill") return { lines: [out(`
  SKILL SET:
  AI Exploration   [██████████████] 74%
  Poster Design    [█████████████░] 68%
  Problem Solving  [████░░░░░░░░░░] 23%
  JavaScript       [████░░░░░░░░░░] 23%
  React            [████░░░░░░░░░░] 22%
  HTML5            [████░░░░░░░░░░] 21%
  CSS3             [███░░░░░░░░░░░] 19%
  CODM Player      [█████████████░] 89% 😎`)] }

  if (cmd === "contact") return { lines: [out(`  CONTACT HYDIR:
  WhatsApp  : wa.me/62895401999318
  Instagram : @dirnust
  GitHub    : github.com/dirv252-stack
  TikTok    : @dirneedlove
  Telegram  : @dircolado
  Twitter   : @DirV267798`)] }

  if (cmd === "social" || cmd === "socials") return { lines: [out(`  SOCIAL MEDIA:
  Instagram : instagram.com/dirnust
  TikTok    : tiktok.com/@dirneedlove
  GitHub    : github.com/dirv252-stack
  Twitter   : x.com/DirV267798
  Telegram  : t.me/dircolado`)] }

  if (cmd === "motto") return { lines: [out(`  "Ga ada yang mustahil kalo lu niat."
  "Flaws don't define failure; giving up does."
  "Logic over luck. Always."
  "Started from zero, still climbing."
  "Learn, build, repeat."`)] }

  if (cmd === "goals" || cmd === "goal") return { lines: [out(`  GOALS:
  - Master JavaScript & React
  - Build 3+ portfolio projects
  - Jadi Full Stack Developer
  - Build produk tech sendiri
  "Every journey starts with a single line of code."`)] }

  if (cmd === "hobbies" || cmd === "hobby") return { lines: [out(`  HOBBIES:
  - Poster Design (Figma, Canva)
  - Gaming (CODM - main character energy!)
  - Explore AI tools
  - Tidur (very important skill)
  - Single & focused (by choice lol 😎)`)] }

  if (cmd === "education" || cmd === "edu") return { lines: [out(`  EDUCATION:
  Self-Taught : Web Development (2024-sekarang)
  Learning    : Full Stack Development
  Resources   : YouTube, docs, AI tools
  Path        : HTML→CSS→JS→React→Next.js`)] }

  if (cmd === "story" || cmd === "journey") return { lines: [out(`  THE JOURNEY:
  2024 : Mulai belajar web development
  2024 : Cuma punya HP (Vivo Y17s)
  2024 : Install Termux + Acode
  2024 : Portfolio pertama dibuat!
  2025 : Portfolio v2.0 ini (yang lg lu liat)
  Next : Full Stack Developer
  "Started from zero, still climbing."`)] }

  if (cmd === "age" || cmd === "born") return { lines: [out(`  Born: 2011
  Age: ${new Date().getFullYear() - 2011} tahun
  "Young and grinding."`)] }

  if (cmd === "projects" || cmd === "portfolio") return { lines: [out(`  PROJECTS:
  [1] Hydir Portfolio v2.0 (ini!)
      Tech: Next.js + React + TypeScript + Tailwind
      Fitur: Terminal, Library, Easter eggs
      URL: dirproject-v1.vercel.app
  [2] More coming soon...`)] }

  if (cmd === "tech" || cmd === "stack") return { lines: [out(`  TECH STACK:
  Languages  : JavaScript, TypeScript, HTML5, CSS3
  Frameworks : React, Next.js, Tailwind, Node.js
  Tools      : Git, GitHub, Termux, Acode, VS Code
  Design     : Figma, Canva, Photoshop (basic)
  Deploy     : Vercel (gratis!)`)] }

  if (cmd === "languages" || cmd === "langs") return { lines: [out(`  LANGUAGES:
  JavaScript 23% (FAVORIT!)
  HTML5      21%
  CSS3       19%
  TypeScript 15%
  Python     12% (masih belajar)`)] }

  if (cmd === "frameworks" || cmd === "framework") return { lines: [out(`  FRAMEWORKS:
  React        22%
  Next.js      20%
  Tailwind CSS 19%
  Node.js      16%`)] }

  if (cmd === "tools" || cmd === "tool") return { lines: [out(`  TOOLS:
  Mobile : Termux, Acode, StackBlitz
  Dev    : Git, GitHub
  Design : Figma, Canva
  Deploy : Vercel`)] }

  if (cmd === "learning") return { lines: [out(`  CURRENTLY LEARNING:
  - Advanced React patterns
  - TypeScript properly
  - Backend dengan Node.js
  - Database (Supabase)
  "Build projects = cara terbaik belajar."`)] }

  if (cmd === "ai") return { lines: [out(`  AI EXPLORATION: 74% (TERTINGGI!)
  Yang gw eksplorasi:
  - AI-assisted development (v0.dev, Copilot)
  - ChatGPT & Claude untuk problem solving
  - AI image generation
  Dream: Build AI-powered web apps
  "AI adalah masa depan. Mulai sekarang!"`)] }

  if (cmd === "pkg upgrade" || cmd === "pkg update") return { lines: [
    out("  Reading package lists..."),
    out("  Calculating upgrade..."),
    out("  [          ] 0%   Downloading..."),
    out("  [██        ] 20%  Verifying..."),
    out("  [█████     ] 50%  Extracting..."),
    out("  [████████  ] 80%  Configuring..."),
    out("  [██████████] 100% Done!"),
    ok ("  Upgrade complete! hydir v2.0 is up to date."),
    out("  System online. Type /hydirmenu"),
  ] }

  if (cmd === "pkg install hydir" || cmd === "pkg install") return { lines: [
    out("  Installing hydir..."),
    ok (`\n  ██╗  ██╗██╗   ██╗██████╗ ██╗██████╗
  ██║  ██║╚██╗ ██╔╝██╔══██╗██║██╔══██╗
  ███████║ ╚████╔╝ ██║  ██║██║██████╔╝
  ██╔══██║  ╚██╔╝  ██║  ██║██║██╔══██╗
  ██║  ██║   ██║   ██████╔╝██║██║  ██║
  ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝╚═╝  ╚═╝\n  Package hydir installed!`),
    out("  Type 'about' to start exploring."),
  ] }

  if (cmd === "pkg list" || cmd === "pkg --list") return { lines: [out(`  INSTALLED PACKAGES:
  hydir          v2.0.1
  next           v16.0.10
  react          v19.2.0
  tailwindcss    v4.1.9
  terminal-cli   v1.0.0`)] }

  if (main === "learn") {
    const topic = parts.slice(1).join(" ")
    const data: Record<string,string> = {
      "html": "  HTML = kerangka website.\n  Pake tags: <h1>, <p>, <div>, <img>\n  Kayak tulang rangka tubuh.\n  Belajar: developer.mozilla.org/HTML",
      "css":  "  CSS = yang bikin website cantik.\n  Atur warna, layout, animasi.\n  Contoh: .box { color: cyan; }\n  Belajar: web.dev/learn/css",
      "js":   "  JavaScript = yang bikin website interaktif.\n  Contoh: const nama = 'Hydir'\n  BAHASA FAVORIT GW!\n  Belajar: javascript.info",
      "react":"  React = library buat bikin UI.\n  Break UI jadi components kecil.\n  Website ini pakai React!\n  Belajar: react.dev",
      "git":  "  Git = time machine untuk kode.\n  git add . → git commit → git push\n  Belajar: git-scm.com",
      "tailwind": "  Tailwind = CSS pakai class names.\n  Contoh: <div class='bg-black text-white p-4'>\n  Belajar: tailwindcss.com",
      "nextjs": "  Next.js = framework di atas React.\n  Auto routing, SEO, image optimization.\n  Website ini pakai Next.js!\n  Belajar: nextjs.org",
    }
    if (data[topic]) return { lines: [out(data[topic])] }
    return { lines: [out(`  Topic tidak ditemukan.
  Coba: learn html, learn css, learn js
  learn react, learn git, learn tailwind`)] }
  }

  if (cmd === "joke") {
    const jokes = [
      "  Q: Kenapa programmer suka dark mode?\n  A: Karena terang itu menarik bugs!",
      "  A: Why did the code break?\n  B: It had too many issues.",
      "  Q: How do you comfort a JS bug?\n  A: You console it.",
    ]
    return { lines: [out(jokes[Math.floor(Math.random() * jokes.length)]), out("  Ketik 'joke' lagi untuk joke berikutnya!")] }
  }

  if (cmd === "quote") {
    const quotes = [
      "  \"First, solve the problem. Then, write the code.\"",
      "  \"The best error message is the one that never shows up.\"",
      "  \"Ga ada yang mustahil kalo lu niat.\" - Hydir",
    ]
    return { lines: [out(quotes[Math.floor(Math.random() * quotes.length)])] }
  }

  if (cmd === "motivate" || cmd === "motivation") return { lines: [ok(`  Lu mulai dari nol. Lihat sejauh mana lu udah jalan.
  Coding dari HP doang? That's insane respect!
  Ga ada yang mustahil kalo lu niat.
  Keep going!`)] }

  if (cmd === "neofetch") return { lines: [out(`
           .       .       Hydir@Portfolio
          /|\\     /|\\      ---------------
         / | \\   / | \\     OS: Next.js 16 on Vercel
        /  |  \\ /  |  \\    Host: Vivo Y17s (8GB RAM)
       /   |   X   |   \\   Shell: TypeScript 5
      /    |  / \\  |    \\  Terminal: Custom CLI v2.0
     /_____|/     \\|_____\\ Editor: Termux + Acode
                          
                           Name  : Hydir (Dirga)
                           Born  : 2011
                           Origin: Jawa Barat
                           Theme : Cyan Dark`)] }

  if (cmd === "hack") return { lines: [
    out("  Initializing hack sequence..."),
    out("  [█████████░] 90%  Almost there..."),
    out("  [██████████] 100% Access granted!"),
    out("  "),
    out("  Just kidding! Hacking is illegal."),
    ok ("  Gw cuma dev yang bikin website keren 😄"),
  ] }

  if (cmd === "matrix") {
    const chars = "01ABCDEF@#$%"
    const lines: Line[] = []
    for (let i = 0; i < 6; i++) {
      let line = "  "
      for (let j = 0; j < 40; j++) line += chars[Math.floor(Math.random() * chars.length)] + " "
      lines.push(out(line))
    }
    lines.push(out("  Welcome to the Matrix. Type 'clear' to exit."))
    return { lines }
  }

  if (cmd === "coffee") return { lines: [out(`  Brewing virtual coffee...
  [██████████] 100% Done!
  ☕ Here's your virtual coffee! Keep coding!`)] }

  if (cmd === "codm" || cmd === "gaming") return { lines: [out(`  CODM STATS (just kidding lol):
  Rank    : Legendary
  K/D     : [CLASSIFIED]
  Status  : Grinding between codes
  "Work hard, play harder."`)] }

  if (cmd === "gf" || cmd === "girlfriend") return { lines: [out(`  Searching for girlfriend...
  [██████████] 100%
  ERROR 404: Girlfriend not found!
  Status   : Single & Focused 💪
  Priority : Code > Everything
  "No gf, no problem. Got goals to chase!"`)] }

  if (cmd === "sleep") return { lines: [out(`  Average sleep: Insufficient 😴
  Reason: Coding + gaming
  "One more commit first..." - me, every night`)] }

  if (cmd === "sigma") return { lines: [out(`  SIGMA MINDSET ACTIVATED 💪
  - Chase goals, not girls
  - Grind in silence
  - Let success make the noise
  - No excuses, only results
  Current Mode: LONE WOLF 🐺`)] }

  if (cmd === "work" || cmd === "grind") return { lines: [ok(`  GRIND MODE ACTIVATED 🔥
  Distractions: DISABLED
  Focus       : MAXIMUM
  "Success comes from consistency, not intensity."`)] }

  if (cmd === "dirga") return { lines: [ok(`  Easter egg ditemukan! 🎉
  Nama asli: Dirga (goes by Hydir)
  Level: Secret unlocked!
  Lu beneran perhatiin detail-detailnya. Respect!`)] }

  if (cmd === "secret" || cmd === "secrets") return { lines: [out(`  SECRET COMMANDS:
  dirga    - Real name reveal
  gf       - Relationship status
  codm     - Gaming stats
  sleep    - Sleep schedule
  sigma    - Sigma grindset
  nocap    - No cap vibes
  based    - Based response`)] }

  if (cmd === "nocap") return { lines: [out("  No cap fr fr.\n  Coding dari HP itu susah. Tapi Hydir lakuin.\n  No cap on the grind.")] }
  if (cmd === "based") return { lines: [out("  Based.\n  Self-taught, coding dari HP, no excuses.\n  That's based behavior.")] }

  if (cmd === "sudo rm -rf /" || cmd === "rm -rf /") return { lines: [err("  Permission denied!\n  Nice try, tapi gak bisa hapus portfolio ini 😄\n  Type 'help' untuk command yang berguna.")] }

  if (cmd === "exit" || cmd === "quit") return { lines: [out("  Mau pergi udah? Masih banyak yang bisa dieksplorasi!\n  Type '/hydirmenu' untuk lihat semua fitur.")] }

  if (cmd === "date") {
    const now = new Date()
    return { lines: [out(`  ${now.toLocaleDateString("id-ID", { weekday:"long", year:"numeric", month:"long", day:"numeric" })}\n  ${now.toLocaleTimeString("id-ID")} WIB`)] }
  }

  if (cmd === "time") return { lines: [out(`  ${new Date().toLocaleTimeString("id-ID")} WIB`)] }

  if (cmd === "version" || cmd === "-v") return { lines: [out("  Hydir Portfolio v2.0\n  Next.js 16 + React 19 + TypeScript + Tailwind CSS v4\n  Built: Dec 11, 2025")] }

  if (cmd === "stats") return { lines: [out("  Terminal Commands : 100+\n  Skills tracked    : 28\n  Library topics    : 57\n  Easter eggs       : 10+\n  Built on          : Vivo Y17s 😤")] }

  if (cmd === "history") return { lines: [out(history.length ? history.map((c,i) => `  ${i+1}. ${c}`).join("\n") : "  Belum ada command history.")] }

  if (cmd === "home" || cmd === "top") {
    window.scrollTo({ top: 0, behavior: "smooth" })
    return { lines: [ok("  Scrolling to top...")] }
  }

  if (cmd === "scroll skills") {
    document.querySelector("#skills")?.scrollIntoView({ behavior: "smooth" })
    return { lines: [ok("  Scrolling ke Skills...")] }
  }

  if (cmd.length > 0) return { lines: [err(`  liat menu goblok\n  Command '${input}' tidak ditemukan.\n  Ketik 'help' untuk lihat semua command.`)] }

  return { lines: [out("  Ketik 'help' untuk mulai.")] }
}

export default function TerminalCLI() {
  const [lines, setLines] = useState<Line[]>([{
    type: "system",
    content: `
  ██╗  ██╗██╗   ██╗██████╗ ██╗██████╗
  ██║  ██║╚██╗ ██╔╝██╔══██╗██║██╔══██╗
  ███████║ ╚████╔╝ ██║  ██║██║██████╔╝
  ██╔══██║  ╚██╔╝  ██║  ██║██║██╔══██╗
  ██║  ██║   ██║   ██████╔╝██║██║  ██║
  ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝╚═╝  ╚═╝
  HYDIR TERMINAL v2.0 — Ketik 'help' atau '/hydirmenu'`
  }])
  const [inputValue, setInputValue]   = useState("")
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex]     = useState(-1)
  const [isVisible, setIsVisible]           = useState(false)
  const bottomRef  = useRef<HTMLDivElement>(null)
  const inputRef   = useRef<HTMLInputElement>(null)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) setIsVisible(true) }, { threshold: 0.1 })
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }) }, [lines])

  const handleSubmit = useCallback(() => {
    if (!inputValue.trim()) return
    const input = inputValue.trim()
    const newHistory = [input, ...commandHistory].slice(0, 50)
    setCommandHistory(newHistory)
    setHistoryIndex(-1)
    const newLines: Line[] = [...lines, { type: "input", content: `hydir@portfolio:~$ ${input}` }]
    const result = processCommand(input, newHistory)
    if (result.action === "clear") { setLines([]) } else { setLines([...newLines, ...result.lines]) }
    setInputValue("")
  }, [inputValue, lines, commandHistory])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") { handleSubmit() }
    else if (e.key === "ArrowUp") { e.preventDefault(); const i = Math.min(historyIndex+1, commandHistory.length-1); setHistoryIndex(i); setInputValue(commandHistory[i]||"") }
    else if (e.key === "ArrowDown") { e.preventDefault(); const i = Math.max(historyIndex-1, -1); setHistoryIndex(i); setInputValue(i===-1?"":commandHistory[i]) }
  }

  return (
    <section ref={sectionRef} id="terminal" className="relative py-32 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className={`text-4xl md:text-5xl font-bold text-center mb-2 text-white tracking-wider transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>TERMINAL</h2>
        <p className={`text-center text-muted-foreground mb-10 tracking-widest text-sm transition-all duration-700 delay-100 ${isVisible ? "opacity-100" : "opacity-0"}`}>INTERACTIVE CLI — Ketik command untuk explore</p>

        <div className={`glassmorphism rounded-2xl overflow-hidden transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10 bg-black/30">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span className="ml-3 text-xs text-white/40 font-mono tracking-widest">hydir@portfolio:~</span>
          </div>

          <div className="h-80 md:h-96 overflow-y-auto p-4 font-mono text-xs md:text-sm bg-black/20 cursor-text" onClick={() => inputRef.current?.focus()}>
            {lines.map((line, i) => (
              <div key={i} className={`whitespace-pre-wrap break-words leading-relaxed mb-0.5 ${line.type==="input"?"text-cyan-300":line.type==="success"?"text-green-400":line.type==="error"?"text-red-400":line.type==="system"?"text-cyan-400":"text-white/70"}`}>
                {line.content}
              </div>
            ))}
            <div ref={bottomRef} />
          </div>

          <div className="flex items-center gap-2 px-4 py-3 border-t border-white/10 bg-black/20">
            <span className="text-cyan-400 font-mono text-xs md:text-sm whitespace-nowrap">hydir@portfolio:~$</span>
            <input ref={inputRef} type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={handleKeyDown} className="flex-1 bg-transparent text-white font-mono text-xs md:text-sm outline-none caret-cyan-400 placeholder-white/20" placeholder="Ketik command... (coba 'help')" autoComplete="off" autoCapitalize="off" spellCheck={false} />
          </div>
        </div>
        <p className="text-center text-white/20 text-xs mt-4 tracking-widest font-mono">↑ ↓ untuk history • 'help' untuk semua command • 100+ commands tersedia</p>
      </div>
    </section>
  )
}
