"use client"

import { useEffect, useState, useCallback } from "react"
import Image from "next/image"
import { BadgeCheck, Code, Sparkles, Zap, Brain, MapPin, Smartphone, Trophy, Palette } from "lucide-react"

const titles = ["Nothing Impossible","Web Developer","Logic Architect","Curiosity Driven","AI Explorer","Code Enthusiast"]

const mottos = [
  "Ga ada yang mustahil kalo lu niat.",
  "Flaws don't define failure; giving up does.",
  "Logic over luck. Always.",
  "Started from zero, still climbing.",
  "Every bug is a lesson, every error a teacher.",
  "Break the logic, rebuild it stronger.",
  "Imperfect code, perfect hustle.",
  "Learn, build, repeat.",
  "Dreams don't work unless you do.",
  "Passion fuels progress.",
]

const quotes = [
  "Karya yang saya buat terlahir dari rasa penasaran saya terhadap suatu hal.",
  "Every project starts with curiosity, berakhir dengan hasil yang beyond expectation.",
  "Started from zero, now we here. Self-taught dev dari Jawa Barat.",
  "From mobile screen to big dreams.",
  "Turning ideas into reality, one line at a time.",
  "Learning never stops, neither do I.",
  "Self-taught, self-made, self-driven.",
  "They said I needed a computer. I proved them wrong.",
  "Passion over perfection, progress over excuses.",
  "Jawa Barat to the world, through code.",
]

const profilePhotos = [
  { src: "/images/profile-ascii.jpg",  alt: "ASCII Profile"    },
  { src: "/images/profile-blur.jpg",   alt: "Artistic Profile" },
  { src: "/images/profile-real.jpg",   alt: "Hydir"            },
]

const achievements = [
  { icon: Code,       label: "Code Starter",      color: "text-cyan-400",    bg: "bg-cyan-400/10",    border: "border-cyan-400/30" },
  { icon: Brain,      label: "Logic Master",      color: "text-purple-400",  bg: "bg-purple-400/10",  border: "border-purple-400/30" },
  { icon: Sparkles,   label: "AI Explorer",       color: "text-amber-400",   bg: "bg-amber-400/10",   border: "border-amber-400/30" },
  { icon: Zap,        label: "Self-Taught",       color: "text-emerald-400", bg: "bg-emerald-400/10", border: "border-emerald-400/30" },
  { icon: MapPin,     label: "Jawa Barat Native", color: "text-blue-400",    bg: "bg-blue-400/10",    border: "border-blue-400/30" },
  { icon: Smartphone, label: "Mobile First",      color: "text-orange-400",  bg: "bg-orange-400/10",  border: "border-orange-400/30" },
]

export default function HeroSection() {
  const [currentTitle, setCurrentTitle]       = useState("")
  const [titleIndex, setTitleIndex]           = useState(0)
  const [isDeleting, setIsDeleting]           = useState(false)
  const [charIndex, setCharIndex]             = useState(0)
  const [showQuote, setShowQuote]             = useState(false)
  const [badgesVisible, setBadgesVisible]     = useState(false)
  const [nameClickCount, setNameClickCount]   = useState(0)
  const [photoClickCount, setPhotoClickCount] = useState(0)
  const [showRealName, setShowRealName]       = useState(false)
  const [showRealPhoto, setShowRealPhoto]     = useState(false)
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0)
  const [currentMottoIndex, setCurrentMottoIndex] = useState(0)
  const [currentQuoteIndex] = useState(() => Math.floor(Math.random() * quotes.length))
  const [photoOpacity, setPhotoOpacity]       = useState(1)
  const [mottoOpacity, setMottoOpacity]       = useState(1)

  useEffect(() => {
    const quoteTimer = setTimeout(() => setShowQuote(true), 1000)
    const badgeTimer = setTimeout(() => setBadgesVisible(true), 500)
    return () => { clearTimeout(quoteTimer); clearTimeout(badgeTimer) }
  }, [])

  useEffect(() => {
    const typingSpeed = isDeleting ? 50 : 100
    if (!isDeleting && charIndex === titles[titleIndex].length) {
      const t = setTimeout(() => setIsDeleting(true), 2000)
      return () => clearTimeout(t)
    }
    if (isDeleting && charIndex === 0) {
      setIsDeleting(false)
      setTitleIndex((prev) => (prev + 1) % titles.length)
      return
    }
    const timeout = setTimeout(() => {
      setCurrentTitle(titles[titleIndex].substring(0, charIndex + (isDeleting ? -1 : 1)))
      setCharIndex((prev) => prev + (isDeleting ? -1 : 1))
    }, typingSpeed)
    return () => clearTimeout(timeout)
  }, [charIndex, isDeleting, titleIndex])

  useEffect(() => {
    if (showRealPhoto) return
    const interval = setInterval(() => {
      setPhotoOpacity(0)
      setTimeout(() => {
        setCurrentPhotoIndex((prev) => (prev + 1) % profilePhotos.length)
        setPhotoOpacity(1)
      }, 400)
    }, 6000)
    return () => clearInterval(interval)
  }, [showRealPhoto])

  useEffect(() => {
    const interval = setInterval(() => {
      setMottoOpacity(0)
      setTimeout(() => {
        setCurrentMottoIndex((prev) => (prev + 1) % mottos.length)
        setMottoOpacity(1)
      }, 500)
    }, 8000)
    return () => clearInterval(interval)
  }, [])

  const handleNameClick = useCallback(() => {
    const newCount = nameClickCount + 1
    setNameClickCount(newCount)
    if (newCount >= 3) {
      setShowRealName(true)
      setNameClickCount(0)
      setTimeout(() => setShowRealName(false), 3000)
    }
  }, [nameClickCount])

  const handlePhotoClick = useCallback(() => {
    const newCount = photoClickCount + 1
    setPhotoClickCount(newCount)
    if (newCount >= 7) {
      setShowRealPhoto(true)
      setCurrentPhotoIndex(2)
      setPhotoClickCount(0)
    }
  }, [photoClickCount])

  const displayPhoto = showRealPhoto ? profilePhotos[2] : profilePhotos[currentPhotoIndex]

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20">
      {showRealName && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="relative bg-gradient-to-br from-red-900/50 to-purple-900/50 border border-red-500/50 rounded-2xl p-8 max-w-sm mx-4 text-center backdrop-blur-xl">
            <div className="absolute inset-0 bg-red-500/10 rounded-2xl animate-pulse" />
            <div className="relative z-10">
              <p className="text-white/60 text-sm mb-2 tracking-widest uppercase">Real Name Unlocked</p>
              <h3 className="text-4xl font-bold text-white mb-1">Dirga</h3>
              <p className="text-red-300 text-sm">goes by HYDIR</p>
              <p className="text-white/40 text-xs mt-4">auto-close in 3s...</p>
            </div>
          </div>
        </div>
      )}

      <div className="relative w-40 h-40 mb-8 animate-pulse-glow rounded-full cursor-pointer select-none" onClick={handlePhotoClick}>
        <div style={{ opacity: photoOpacity, transition: "opacity 0.4s ease" }}>
          <Image src={displayPhoto.src} alt={displayPhoto.alt} width={160} height={160} className="rounded-full object-cover border-4 border-primary w-40 h-40" priority />
        </div>
        <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-400 rounded-full animate-pulse border-2 border-black" />
        {photoClickCount > 0 && photoClickCount < 7 && (
          <div className="absolute -bottom-7 left-1/2 -translate-x-1/2 text-xs text-white/40 whitespace-nowrap">
            {7 - photoClickCount} more clicks...
          </div>
        )}
      </div>

      <div className="flex items-center gap-2 mb-6 cursor-pointer select-none" onClick={handleNameClick}>
        <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight hover:text-cyan-300 transition-colors duration-300">HYDIR</h1>
        <BadgeCheck className="w-8 h-8 md:w-10 md:h-10 text-red-500 fill-red-500/20" />
      </div>

      <div className="flex flex-wrap justify-center gap-3 mb-8 max-w-lg">
        {achievements.map((badge, index) => (
          <div key={badge.label} className={`flex items-center gap-2 px-4 py-2 ${badge.bg} border ${badge.border} rounded-full backdrop-blur-md hover:scale-110 hover:shadow-lg hover:shadow-cyan-500/20 transition-all duration-300 cursor-default group ${badgesVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`} style={{ transitionDelay: `${index * 120}ms` }}>
            <badge.icon className={`w-4 h-4 ${badge.color} group-hover:animate-pulse`} />
            <span className={`text-sm font-medium ${badge.color}`}>{badge.label}</span>
          </div>
        ))}
      </div>

      <div className="h-16 md:h-20 flex items-center mb-6">
        <h2 className="text-2xl md:text-4xl font-medium text-primary min-w-[300px] md:min-w-[500px] text-center">
          {currentTitle}<span className="animate-pulse ml-0.5">|</span>
        </h2>
      </div>

      <div className="mb-6 px-4 py-2 rounded-lg border border-cyan-500/20 bg-cyan-500/5 max-w-2xl mx-4" style={{ opacity: mottoOpacity, transition: "opacity 0.5s ease" }}>
        <p className="text-cyan-300 text-sm md:text-base text-center font-medium tracking-wide">&quot;{mottos[currentMottoIndex]}&quot;</p>
      </div>

      <blockquote className={`text-base md:text-lg text-muted-foreground max-w-2xl text-center leading-relaxed px-4 transition-all duration-1000 ${showQuote ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        &quot;{quotes[currentQuoteIndex]}&quot;
      </blockquote>

      <div className={`mt-6 flex flex-wrap justify-center gap-4 text-xs text-white/30 transition-all duration-1000 delay-500 ${showQuote ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
        <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> Jawa Barat, Indonesia</span>
        <span className="flex items-center gap-1"><Smartphone className="w-3 h-3" /> Built on Mobile</span>
        <span className="flex items-center gap-1"><Trophy className="w-3 h-3" /> Available for Projects</span>
        <span className="flex items-center gap-1"><Palette className="w-3 h-3" /> Poster Designer</span>
      </div>
    </section>
  )
}
