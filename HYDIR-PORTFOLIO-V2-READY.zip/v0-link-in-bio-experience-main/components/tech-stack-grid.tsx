"use client"

import { useEffect, useRef, useState } from "react"
import { Code2, Palette, Brain, Database, Globe, Layers, Cpu, Sparkles } from "lucide-react"

const techStack = [
  { name: "React", icon: Code2, color: "#61DAFB", delay: 0 },
  { name: "Next.js", icon: Globe, color: "#ffffff", delay: 0.1 },
  { name: "TypeScript", icon: Code2, color: "#3178C6", delay: 0.2 },
  { name: "Tailwind", icon: Palette, color: "#06B6D4", delay: 0.3 },
  { name: "Node.js", icon: Cpu, color: "#339933", delay: 0.4 },
  { name: "AI/ML", icon: Brain, color: "#00E5FF", delay: 0.5 },
  { name: "Database", icon: Database, color: "#FF6B6B", delay: 0.6 },
  { name: "UI/UX", icon: Layers, color: "#A855F7", delay: 0.7 },
]

export default function TechStackGrid() {
  const [isVisible, setIsVisible] = useState(false)
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null)
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 px-4 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-transparent pointer-events-none" />

      <div className="max-w-4xl mx-auto">
        {/* Section header */}
        <div
          className={`text-center mb-16 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <span className="text-cyan-400 text-sm tracking-[0.3em] uppercase">Arsenal</span>
            <Sparkles className="w-5 h-5 text-cyan-400" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Tech Stack</h2>
          <p className="text-white/50 max-w-md mx-auto">Tools and technologies I wield to bring ideas to life</p>
        </div>

        {/* Tech grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {techStack.map((tech, index) => {
            const Icon = tech.icon
            return (
              <div
                key={tech.name}
                className={`group relative transition-all duration-500 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
                }`}
                style={{ transitionDelay: `${tech.delay}s` }}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <div
                  className={`glassmorphism rounded-2xl p-6 text-center transition-all duration-300 cursor-pointer
                  ${hoveredIndex === index ? "scale-110 border-cyan-400/50" : "scale-100"}
                `}
                  style={{
                    boxShadow: hoveredIndex === index ? `0 0 30px ${tech.color}40, 0 0 60px ${tech.color}20` : "none",
                  }}
                >
                  {/* Floating icon */}
                  <div
                    className={`mx-auto mb-4 w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 ${
                      hoveredIndex === index ? "animate-float" : ""
                    }`}
                    style={{
                      backgroundColor: `${tech.color}15`,
                      boxShadow: hoveredIndex === index ? `0 0 20px ${tech.color}50` : "none",
                    }}
                  >
                    <Icon className="w-6 h-6 transition-all duration-300" style={{ color: tech.color }} />
                  </div>

                  <h3 className="text-white font-medium text-sm">{tech.name}</h3>

                  {/* Hover shine effect */}
                  <div
                    className={`absolute inset-0 rounded-2xl overflow-hidden pointer-events-none ${
                      hoveredIndex === index ? "opacity-100" : "opacity-0"
                    }`}
                  >
                    <div
                      className="absolute inset-0 translate-x-[-100%] animate-shimmer"
                      style={{
                        background: `linear-gradient(90deg, transparent, ${tech.color}10, transparent)`,
                        backgroundSize: "200% 100%",
                      }}
                    />
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
