"use client"

import { useEffect, useRef, useState } from "react"

const skills = [
  { name: "AI Exploration",      percentage: 74, color: "from-cyan-400 to-blue-500",     category: "AI & Logic"  },
  { name: "Poster Design",       percentage: 68, color: "from-pink-500 to-purple-500",   category: "Design"      },
  { name: "Problem Solving",     percentage: 23, color: "from-purple-400 to-indigo-500", category: "AI & Logic"  },
  { name: "Creative Thinking",   percentage: 22, color: "from-rose-400 to-pink-500",     category: "AI & Logic"  },
  { name: "Logic Building",      percentage: 21, color: "from-indigo-400 to-cyan-500",   category: "AI & Logic"  },
  { name: "JavaScript",          percentage: 23, color: "from-yellow-400 to-amber-500",  category: "Languages"   },
  { name: "HTML5",               percentage: 21, color: "from-orange-400 to-red-500",    category: "Languages"   },
  { name: "CSS3",                percentage: 19, color: "from-blue-400 to-indigo-500",   category: "Languages"   },
  { name: "TypeScript",          percentage: 15, color: "from-blue-500 to-blue-700",     category: "Languages"   },
  { name: "Python Basics",       percentage: 12, color: "from-green-400 to-teal-500",    category: "Languages"   },
  { name: "React",               percentage: 22, color: "from-cyan-400 to-blue-400",     category: "Frameworks"  },
  { name: "Next.js",             percentage: 20, color: "from-gray-300 to-white",        category: "Frameworks"  },
  { name: "Tailwind CSS",        percentage: 19, color: "from-teal-400 to-cyan-500",     category: "Frameworks"  },
  { name: "Node.js",             percentage: 16, color: "from-green-500 to-emerald-500", category: "Frameworks"  },
  { name: "Git",                 percentage: 19, color: "from-orange-500 to-red-600",    category: "Tools"       },
  { name: "GitHub",              percentage: 18, color: "from-gray-400 to-gray-600",     category: "Tools"       },
  { name: "VS Code / Acode",     percentage: 17, color: "from-blue-500 to-cyan-500",     category: "Tools"       },
  { name: "Termux",              percentage: 16, color: "from-green-600 to-green-400",   category: "Tools"       },
  { name: "Figma",               percentage: 16, color: "from-purple-400 to-pink-400",   category: "Tools"       },
  { name: "Canva",               percentage: 15, color: "from-blue-400 to-purple-500",   category: "Tools"       },
  { name: "UI Design",           percentage: 20, color: "from-purple-500 to-pink-500",   category: "Design"      },
  { name: "Responsive Design",   percentage: 19, color: "from-cyan-500 to-teal-500",     category: "Design"      },
  { name: "Graphic Design",      percentage: 18, color: "from-rose-500 to-orange-500",   category: "Design"      },
  { name: "Color Theory",        percentage: 15, color: "from-amber-400 to-yellow-500",  category: "Design"      },
  { name: "Vercel Deployment",   percentage: 16, color: "from-gray-300 to-white",        category: "Web"         },
  { name: "Web Performance",     percentage: 15, color: "from-green-400 to-cyan-400",    category: "Web"         },
  { name: "Mobile-First Dev",    percentage: 15, color: "from-blue-400 to-indigo-500",   category: "Web"         },
  { name: "CODM Player",         percentage: 89, color: "from-red-500 to-orange-600",    category: "Gaming"      },
]

const categories = ["All", "AI & Logic", "Languages", "Frameworks", "Tools", "Design", "Web", "Gaming"]

export default function SkillLab() {
  const [isVisible, setIsVisible]             = useState(false)
  const [animatedPercentages, setAnimatedPercentages] = useState(skills.map(() => 0))
  const [activeCategory, setActiveCategory]   = useState("All")
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) setIsVisible(true) }, { threshold: 0.1 })
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (!isVisible) return
    skills.forEach((skill, index) => {
      let current = 0
      const increment = skill.percentage / 60
      const timer = setInterval(() => {
        current += increment
        if (current >= skill.percentage) { current = skill.percentage; clearInterval(timer) }
        setAnimatedPercentages((prev) => { const n = [...prev]; n[index] = Math.round(current); return n })
      }, 25)
    })
  }, [isVisible])

  const filteredSkills = activeCategory === "All" ? skills : skills.filter((s) => s.category === activeCategory)

  return (
    <section ref={sectionRef} className="relative py-32 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-2 text-white tracking-wider">THE PROCESS</h2>
        <p className="text-center text-muted-foreground mb-8 tracking-widest text-sm">SKILL LAB — What I&apos;m capable of</p>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-wider transition-all duration-300 border ${activeCategory === cat ? "bg-cyan-500/20 border-cyan-500/60 text-cyan-300 shadow-[0_0_15px_rgba(0,229,255,0.3)]" : "bg-transparent border-white/10 text-white/40 hover:border-white/30 hover:text-white/60"}`}>
              {cat}
            </button>
          ))}
        </div>

        <div className="space-y-5">
          {filteredSkills.map((skill, index) => {
            const originalIndex = skills.findIndex((s) => s.name === skill.name)
            return (
              <div key={skill.name} className={`glassmorphism p-5 md:p-6 rounded-2xl transition-all duration-500 hover:scale-[1.02] hover:shadow-[0_0_40px_rgba(0,229,255,0.15)] ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`} style={{ transitionDelay: `${index * 40}ms` }}>
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <h3 className="text-base md:text-lg font-semibold text-white">{skill.name}</h3>
                    <span className="text-xs text-white/30 tracking-widest uppercase">{skill.category}</span>
                  </div>
                  <span className="text-xl md:text-2xl font-bold text-primary">{animatedPercentages[originalIndex]}%</span>
                </div>
                <div className="h-2.5 bg-secondary rounded-full overflow-hidden">
                  <div className={`h-full bg-gradient-to-r ${skill.color} transition-all duration-1000 ease-out relative rounded-full`} style={{ width: `${animatedPercentages[originalIndex]}%` }}>
                    <div className="absolute inset-0 animate-shimmer rounded-full" style={{ backgroundImage: "linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)", backgroundSize: "200% 100%" }} />
                  </div>
                </div>
              </div>
            )
          })}
        </div>
        <p className="text-center text-white/20 text-xs mt-12 tracking-widest">SKILLS UPDATE REGULARLY — Always learning, always growing</p>
      </div>
    </section>
  )
}
