"use client"

import { useEffect, useRef, useState } from "react"

type Topic = { id:string; title:string; category:string; icon:string; desc:string; more:string; link:string }

const topics: Topic[] = [
  { id:"html",     title:"Apa itu HTML?",           category:"HTML",       icon:"H", desc:"HTML = kerangka semua website. Pakai tags kayak <div>, <p>, <h1>. Kayak tulang rangka tubuh.",                                                        more:"HTML bukan programming language, tapi markup language. Setiap elemen punya opening & closing tag: <p>text</p>.",               link:"developer.mozilla.org/HTML" },
  { id:"html-el",  title:"HTML Elements",           category:"HTML",       icon:"H", desc:"Building blocks website. Ada heading <h1-h6>, paragraph <p>, container <div>, link <a>, gambar <img>, dll.",                                          more:"Element punya attribute. Contoh: <a href='url'>Link</a>. href adalah attribute yang kasih tau kemana link mengarah.",           link:"developer.mozilla.org/HTML/Element" },
  { id:"html-form",title:"HTML Forms",              category:"HTML",       icon:"H", desc:"Form untuk input data dari user. Ada <input>, <textarea>, <button>. Dipakai di login, kontak, search, dll.",                                           more:"Input punya berbagai type: text, email, password, number, checkbox, radio, dll.",                                              link:"developer.mozilla.org/HTML/Element/form" },
  { id:"semantic", title:"Semantic HTML",           category:"HTML",       icon:"H", desc:"Pakai tags bermakna: <header>, <nav>, <main>, <article>, <footer>. Lebih readable dan SEO-friendly.",                                                   more:"Search engine kayak Google lebih ngerti struktur website kalau pakai semantic HTML.",                                          link:"web.dev/learn/html/semantic-html" },
  { id:"meta",     title:"Meta Tags",               category:"HTML",       icon:"H", desc:"Ada di <head>, tidak kelihatan di browser tapi penting buat SEO dan social sharing preview.",                                                          more:"Meta tags penting: title, description, og:image, viewport.",                                                                  link:"developer.mozilla.org/HTML/Element/meta" },
  { id:"css",      title:"Apa itu CSS?",            category:"CSS",        icon:"C", desc:"CSS bikin website jadi cantik. Atur warna, layout, font, animasi. HTML adalah rumah, CSS adalah catnya.",                                              more:"CSS pakai selector buat target element HTML, terus kasih styles. External file .css adalah best practice.",                  link:"web.dev/learn/css" },
  { id:"selector", title:"CSS Selectors",           category:"CSS",        icon:"C", desc:"Target HTML elements. Element selector (p), class (.class), ID (#id), pseudo-class (:hover).",                                                        more:"Specificity: ID (100) > Class (10) > Element (1). Lebih spesifik = lebih prioritas.",                                        link:"css-tricks.com/almanac/selectors" },
  { id:"flexbox",  title:"CSS Flexbox",             category:"CSS",        icon:"C", desc:"Layout 1D. Atur elemen dalam satu baris/kolom. Gunakan display:flex pada container.",                                                                  more:"justify-content (horizontal), align-items (vertical), flex-direction, gap. Sangat powerful!",                                link:"css-tricks.com/snippets/css/a-guide-to-flexbox" },
  { id:"grid",     title:"CSS Grid",                category:"CSS",        icon:"C", desc:"Layout 2D. Atur elemen dalam baris DAN kolom. Perfect untuk dashboard atau complex layouts.",                                                          more:"grid-template-columns, grid-template-rows, gap, grid-column. Lebih powerful dari Flexbox untuk 2D!",                        link:"css-tricks.com/snippets/css/complete-guide-grid" },
  { id:"responsive",title:"Responsive Design",     category:"CSS",        icon:"C", desc:"Website yang bagus di semua layar. Pakai media queries dan mobile-first approach.",                                                                     more:"@media (max-width: 768px) {} → Design untuk HP dulu, baru scale up!",                                                        link:"web.dev/learn/design" },
  { id:"animation",title:"CSS Animations",         category:"CSS",        icon:"C", desc:"Animasi tanpa JavaScript! Pakai @keyframes. Lebih smooth dan hemat performa.",                                                                         more:"@keyframes nama { from{} to{} } .el { animation: nama 2s ease infinite }",                                                   link:"developer.mozilla.org/CSS/animation" },
  { id:"tailwind", title:"Tailwind CSS",            category:"CSS",        icon:"C", desc:"Utility-first CSS. Style langsung di HTML pakai class names: text-white, bg-black, p-4, rounded-lg.",                                                  more:"Website ini pakai Tailwind! No custom CSS - semua via utility classes. Faster development!",                                  link:"tailwindcss.com" },
  { id:"js",       title:"Apa itu JavaScript?",    category:"JavaScript", icon:"J", desc:"Programming language untuk web. Bikin website interaktif. Jalan di browser DAN server (Node.js). Paling populer!",                                     more:"JS bisa manipulate HTML/CSS, handle events, fetch data dari API. Every interactive website pakai JS.",                       link:"javascript.info" },
  { id:"variables",title:"Variables & Data Types", category:"JavaScript", icon:"J", desc:"Variables simpan data. let (bisa diubah), const (tetap). Types: string, number, boolean, array, object.",                                              more:"const nama = 'Hydir' // string. let umur = 14 // number. const list = [1,2,3] // array.",                                    link:"javascript.info/variables" },
  { id:"functions",title:"Functions",              category:"JavaScript", icon:"J", desc:"Kode yang bisa dipanggil berkali-kali. Arrow function: const sapa = (nama) => 'Hello ' + nama",                                                        more:"Declare sekali, gunakan berkali-kali. Bisa punya parameter dan return value.",                                                link:"javascript.info/function-basics" },
  { id:"arrays",   title:"Arrays",                 category:"JavaScript", icon:"J", desc:"Daftar nilai. const buah = ['mangga','apel']. Methods: push, pop, map, filter, find, forEach.",                                                        more:"buah.push('pisang') // tambah. buah.map(b => b.toUpperCase()) // transform. buah.filter(b => b.length>5) // filter.",       link:"javascript.info/array" },
  { id:"objects",  title:"Objects",                category:"JavaScript", icon:"J", desc:"Kumpulan key-value. const user = {name:'Hydir', age:14}. Akses: user.name",                                                                            more:"Destructuring: const {name, age} = user. Spread: {...user, newKey: 'val'}",                                                  link:"javascript.info/object" },
  { id:"loops",    title:"Loops",                  category:"JavaScript", icon:"J", desc:"Ulangi kode. for, while, forEach, map. Pilih sesuai kebutuhan!",                                                                                       more:"for (let i=0; i<10; i++) {} // classic. array.forEach(item => {}) // untuk array.",                                          link:"javascript.info/while-for" },
  { id:"dom",      title:"DOM Manipulation",       category:"JavaScript", icon:"J", desc:"Manipulasi HTML pakai JS. querySelector, innerHTML, style, dll.",                                                                                       more:"const el = document.querySelector('.class') // select. el.textContent = 'new' // ganti teks.",                               link:"javascript.info/document" },
  { id:"events",   title:"Events",                 category:"JavaScript", icon:"J", desc:"Klik, scroll, ketik, hover → trigger kode. addEventListener untuk 'dengarkan' events.",                                                                more:"button.addEventListener('click', () => { alert('Clicked!') }). Types: click, input, keydown, scroll.",                       link:"javascript.info/events" },
  { id:"async",    title:"Async / Await",          category:"JavaScript", icon:"J", desc:"Handle operasi yang butuh waktu (fetch data, dll). async function + await keyword.",                                                                    more:"async function getData() { const res = await fetch(url); const data = await res.json(); return data; }",                    link:"javascript.info/async-await" },
  { id:"es6",      title:"ES6+ Features",          category:"JavaScript", icon:"J", desc:"Fitur modern JS: arrow functions, destructuring, spread, template literals, modules.",                                                                  more:"Template literal: `Hello ${name}!` // interpolation. Destructuring: const {a,b}=obj. Spread: [...arr1,...arr2].",            link:"javascript.info/modern-js" },
  { id:"react",    title:"Apa itu React?",         category:"React",      icon:"R", desc:"Library untuk bikin UI. Break UI jadi reusable components. Function components + hooks.",                                                               more:"Component = function yang return JSX. Props = data dari parent. State = data internal.",                                      link:"react.dev" },
  { id:"hooks",    title:"React Hooks",            category:"React",      icon:"R", desc:"useState (data), useEffect (side effects), useCallback, useMemo. Special functions React.",                                                             more:"const [count, setCount] = useState(0). useEffect(() => { /* run after render */ }, [deps]).",                               link:"react.dev/reference/react" },
  { id:"props",    title:"Props & State",          category:"React",      icon:"R", desc:"Props = data dari parent ke child (read-only). State = data internal yang bisa berubah dan trigger re-render.",                                         more:"Props mengalir satu arah: parent → child. Kalau butuh pass data ke atas, pakai callback function.",                          link:"react.dev/learn/passing-props-to-a-component" },
  { id:"nextjs",   title:"Apa itu Next.js?",       category:"Next.js",    icon:"N", desc:"React framework yang udah setup perfect. Auto routing, image optimization, SEO-friendly. Website ini pakai Next.js!",                                   more:"App Router: folder = route. app/about/page.tsx = /about. Server Components = faster!",                                       link:"nextjs.org" },
  { id:"routing",  title:"Next.js Routing",        category:"Next.js",    icon:"N", desc:"File-based routing. Bikin file di app/ = jadi route otomatis. app/blog/page.tsx = /blog.",                                                             more:"Dynamic routes: app/blog/[id]/page.tsx → /blog/1, /blog/2. Loading: loading.tsx = skeleton UI.",                            link:"nextjs.org/docs" },
  { id:"git",      title:"Apa itu Git?",           category:"Tools",      icon:"G", desc:"Time machine untuk kode. Save snapshots (commits), undo changes, branch untuk eksperimen.",                                                            more:"git init → git add . → git commit -m 'pesan' → git push. Wajib dipelajari!",                                                link:"git-scm.com" },
  { id:"gitcmd",   title:"Git Commands",           category:"Tools",      icon:"G", desc:"init, clone, add, commit, push, pull, status, log, branch, merge, checkout.",                                                                          more:"git status // lihat perubahan. git log --oneline // history. git diff // lihat perbedaan.",                                  link:"git-scm.com/docs" },
  { id:"github",   title:"Apa itu GitHub?",        category:"Tools",      icon:"G", desc:"Platform host kode online berbasis Git. Simpan project, collaborate, showcase portfolio.",                                                              more:"Pull Requests = propose perubahan. Issues = bug tracker. GitHub Pages = host website gratis!",                               link:"github.com" },
  { id:"terminal", title:"Terminal Basics",        category:"Tools",      icon:"G", desc:"Interface teks untuk interact dengan sistem. Di HP: Termux. ls, cd, mkdir, rm, cat.",                                                                  more:"pwd // print dir. ls -la // list file. cd folder // masuk. cd .. // keluar. mkdir nama // bikin folder.",                   link:"ubuntu.com/tutorials/command-line-for-beginners" },
  { id:"npm",      title:"Package Managers",       category:"Tools",      icon:"G", desc:"npm/pnpm/yarn download dan manage libraries. npm install react, pnpm add tailwindcss.",                                                                 more:"package.json = daftar dependencies. node_modules = tempat libraries terinstall (jangan di-commit ke git).",                  link:"docs.npmjs.com" },
  { id:"vercel",   title:"Vercel Deployment",      category:"Tools",      icon:"G", desc:"Deploy website gratis. Connect GitHub → push kode → otomatis deploy. HTTPS auto, CDN global.",                                                         more:"Domain gratis: project.vercel.app. Custom domain bisa dihubungkan. Analytics built-in!",                                     link:"vercel.com" },
  { id:"vscode",   title:"VS Code / Acode",        category:"Tools",      icon:"G", desc:"VS Code = editor paling populer. Di HP pakai Acode. Extensions: Prettier, ESLint, GitLens.",                                                          more:"Shortcuts: Ctrl+P (find file), Ctrl+Shift+P (command palette), Ctrl+/ (comment).",                                          link:"code.visualstudio.com" },
  { id:"color",    title:"Color Theory",           category:"Design",     icon:"D", desc:"Ilmu tentang warna. Primary colors, complementary, color harmony. Penting untuk UI yang enak dipandang.",                                              more:"Monochromatic (satu warna beda shade), Complementary (berlawanan). Website ini: Black + Cyan.",                              link:"color.adobe.com" },
  { id:"typo",     title:"Typography",             category:"Design",     icon:"D", desc:"Seni mengatur teks. Font family, size, line height, letter spacing, weight. Penting untuk readability.",                                               more:"Font pairing: max 2-3 fonts. Line height 1.5-1.6 untuk body. Website ini: Space Grotesk.",                                  link:"fonts.google.com" },
  { id:"layout",   title:"Layout Principles",      category:"Design",     icon:"D", desc:"Visual hierarchy, white space, grid, alignment, contrast, repetition.",                                                                                more:"Rule of thirds, F-pattern reading. Cards, grids, flexbox. Consistent spacing.",                                             link:"web.dev/learn/design" },
  { id:"mobile",   title:"Mobile-First Design",    category:"Design",     icon:"D", desc:"Design untuk layar kecil dulu, scale up untuk besar. 60%+ web traffic dari HP.",                                                                       more:"Viewport meta tag wajib. Touch targets min 44x44px. Fast load time sangat penting di mobile.",                              link:"web.dev/explore/mobile" },
  { id:"a11y",     title:"Accessibility",          category:"Design",     icon:"D", desc:"Website bisa diakses semua orang. Alt text, keyboard nav, color contrast.",                                                                            more:"Alt text: <img alt='deskripsi'>. Color contrast ratio min 4.5:1. ARIA labels untuk screen readers.",                        link:"web.dev/learn/accessibility" },
  { id:"perf",     title:"Web Performance",        category:"Performance",icon:"P", desc:"Seberapa cepat website load. Core Web Vitals: LCP, FID, CLS. Target: load < 3 detik.",                                                                more:"Tips: compress images, lazy load, code splitting, caching, minify JS/CSS, CDN.",                                             link:"web.dev/performance" },
  { id:"imgopt",   title:"Image Optimization",     category:"Performance",icon:"P", desc:"Images sering jadi penyebab website lambat. Compress (TinyPNG), format WebP, lazy load.",                                                              more:"next/image otomatis optimize. WebP 30-40% lebih kecil dari JPEG. loading='lazy' untuk non-critical images.",                 link:"web.dev/fast/serve-images-webp" },
  { id:"cleancode",title:"Code Organization",      category:"Performance",icon:"P", desc:"Clean code = mudah dibaca. Naming conventions, comments, folder structure, DRY principle.",                                                             more:"camelCase (variables), PascalCase (components). Comments = jelasin KENAPA, bukan WHAT.",                                    link:"clean-code.js.org" },
  { id:"start",    title:"Cara Mulai Coding",      category:"Career",     icon:"L", desc:"Pilih satu bahasa (HTML/CSS/JS), belajar basics, bikin project kecil, konsisten!",                                                                     more:"Roadmap: HTML → CSS → JavaScript → React → Next.js. Build projects = cara terbaik belajar.",                                link:"roadmap.sh" },
  { id:"resources",title:"Learning Resources",     category:"Career",     icon:"L", desc:"Gratis: freeCodeCamp, MDN Web Docs, javascript.info, CSS-Tricks, YouTube.",                                                                            more:"YouTube channels: Traversy Media, Fireship, Kevin Powell. Community: Discord, Stack Overflow, DEV.to.",                     link:"freeCodeCamp.org" },
  { id:"portfolio",title:"Building Portfolio",     category:"Career",     icon:"L", desc:"Showcase skill dan project. Harus ada: profil, project dengan deskripsi, cara kontak, GitHub.",                                                        more:"Quality > Quantity. 3-5 project bagus > 20 project jelek. Deploy semua! Keep it updated.",                                  link:"github.com" },
]

const categories = ["All","HTML","CSS","JavaScript","React","Next.js","Tools","Design","Performance","Career"]

const catColor: Record<string,string> = {
  "HTML":"text-orange-400 bg-orange-400/10 border-orange-400/30",
  "CSS":"text-blue-400 bg-blue-400/10 border-blue-400/30",
  "JavaScript":"text-yellow-400 bg-yellow-400/10 border-yellow-400/30",
  "React":"text-cyan-400 bg-cyan-400/10 border-cyan-400/30",
  "Next.js":"text-white bg-white/10 border-white/20",
  "Tools":"text-green-400 bg-green-400/10 border-green-400/30",
  "Design":"text-pink-400 bg-pink-400/10 border-pink-400/30",
  "Performance":"text-purple-400 bg-purple-400/10 border-purple-400/30",
  "Career":"text-emerald-400 bg-emerald-400/10 border-emerald-400/30",
}

export default function MiniLibrary() {
  const [isVisible, setIsVisible]           = useState(false)
  const [activeCategory, setActiveCategory] = useState("All")
  const [selectedTopic, setSelectedTopic]   = useState<Topic|null>(null)
  const [searchQuery, setSearchQuery]       = useState("")
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => { if (entry.isIntersecting) setIsVisible(true) }, { threshold: 0.1 })
    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  const filteredTopics = topics.filter((t) => {
    const matchCat = activeCategory === "All" || t.category === activeCategory
    const matchSearch = searchQuery === "" || t.title.toLowerCase().includes(searchQuery.toLowerCase()) || t.desc.toLowerCase().includes(searchQuery.toLowerCase())
    return matchCat && matchSearch
  })

  return (
    <section ref={sectionRef} id="library" className="relative py-32 px-4">
      <div className="max-w-6xl mx-auto">
        <h2 className={`text-4xl md:text-5xl font-bold text-center mb-2 text-white tracking-wider transition-all duration-700 ${isVisible?"opacity-100 translate-y-0":"opacity-0 translate-y-8"}`}>MINI LIBRARY</h2>
        <p className={`text-center text-muted-foreground mb-10 tracking-widest text-sm transition-all duration-700 delay-100 ${isVisible?"opacity-100":"opacity-0"}`}>BELAJAR TECH BASICS — Simple & to the point</p>

        <div className={`max-w-md mx-auto mb-8 transition-all duration-700 delay-200 ${isVisible?"opacity-100 translate-y-0":"opacity-0 translate-y-4"}`}>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30 text-sm">{">"}</span>
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Cari topik... (html, css, js, react)" className="w-full bg-white/5 border border-white/10 rounded-xl pl-8 pr-4 py-3 text-white text-sm font-mono outline-none focus:border-cyan-500/50 transition-all placeholder-white/20" />
          </div>
        </div>

        <div className={`flex flex-wrap justify-center gap-2 mb-10 transition-all duration-700 delay-300 ${isVisible?"opacity-100":"opacity-0"}`}>
          {categories.map((cat) => (
            <button key={cat} onClick={() => setActiveCategory(cat)} className={`px-4 py-1.5 rounded-full text-xs font-medium tracking-wider transition-all duration-300 border ${activeCategory===cat?"bg-cyan-500/20 border-cyan-500/60 text-cyan-300 shadow-[0_0_15px_rgba(0,229,255,0.2)]":"bg-transparent border-white/10 text-white/40 hover:border-white/30 hover:text-white/60"}`}>{cat}</button>
          ))}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {filteredTopics.map((topic, i) => (
            <button key={topic.id} onClick={() => setSelectedTopic(topic)} className={`glassmorphism rounded-xl p-4 text-left hover:scale-105 hover:border-cyan-500/30 hover:shadow-[0_0_20px_rgba(0,229,255,0.1)] transition-all duration-300 ${isVisible?"opacity-100 translate-y-0":"opacity-0 translate-y-8"}`} style={{ transitionDelay: `${(i%16)*40}ms` }}>
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm mb-3 border ${catColor[topic.category]||"text-white bg-white/10 border-white/20"}`}>{topic.icon}</div>
              <p className="text-white text-xs font-medium leading-tight">{topic.title}</p>
              <span className={`text-xs mt-2 inline-block ${(catColor[topic.category]||"text-white/40").split(" ")[0]}`}>{topic.category}</span>
            </button>
          ))}
        </div>

        {filteredTopics.length === 0 && (
          <div className="text-center py-16">
            <p className="text-white/30 text-sm font-mono">Tidak ada topik untuk &quot;{searchQuery}&quot;</p>
            <button onClick={() => { setSearchQuery(""); setActiveCategory("All") }} className="mt-4 text-cyan-400 text-xs hover:underline">Reset filter</button>
          </div>
        )}
        <p className="text-center text-white/20 text-xs mt-10 tracking-widest">{filteredTopics.length} topik tersedia • Klik untuk baca penjelasan</p>
      </div>

      {selectedTopic && (
        <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setSelectedTopic(null)}>
          <div className="w-full max-w-lg bg-[#0a0a0a] border border-white/10 rounded-2xl overflow-hidden animate-fade-in-scale" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold border ${catColor[selectedTopic.category]||"text-white bg-white/10 border-white/20"}`}>{selectedTopic.icon}</div>
              <div className="flex-1">
                <h3 className="text-white font-semibold text-sm">{selectedTopic.title}</h3>
                <span className={`text-xs ${(catColor[selectedTopic.category]||"text-white/40").split(" ")[0]}`}>{selectedTopic.category}</span>
              </div>
              <button onClick={() => setSelectedTopic(null)} className="text-white/40 hover:text-white text-xl transition-colors">×</button>
            </div>
            <div className="p-5 space-y-4 max-h-96 overflow-y-auto">
              <p className="text-white/80 text-sm leading-relaxed">{selectedTopic.desc}</p>
              <div className="h-px bg-white/5" />
              <p className="text-white/60 text-sm leading-relaxed">{selectedTopic.more}</p>
              <div className="pt-2"><span className="text-white/30 text-xs">Belajar lebih: </span><span className="text-cyan-400 text-xs font-mono">{selectedTopic.link}</span></div>
            </div>
            <div className="px-5 py-3 border-t border-white/10 flex justify-between items-center">
              <span className="text-white/20 text-xs">Tap di luar untuk tutup</span>
              <button onClick={() => setSelectedTopic(null)} className="px-4 py-1.5 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-300 text-xs hover:bg-cyan-500/20 transition-colors">Tutup</button>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
