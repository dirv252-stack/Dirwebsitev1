"use client"

import { useEffect, useRef, useState } from "react"

interface ScrollTextRevealProps {
  text: string
  className?: string
}

export default function ScrollTextReveal({ text, className = "" }: ScrollTextRevealProps) {
  const [visibleChars, setVisibleChars] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      if (!containerRef.current) return

      const rect = containerRef.current.getBoundingClientRect()
      const windowHeight = window.innerHeight

      // Calculate progress based on element position
      const start = windowHeight
      const end = -rect.height
      const current = rect.top

      const progress = Math.max(0, Math.min(1, (start - current) / (start - end)))
      const charsToShow = Math.floor(progress * text.length * 1.5) // 1.5x for faster reveal

      setVisibleChars(Math.min(charsToShow, text.length))
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll() // Initial check

    return () => window.removeEventListener("scroll", handleScroll)
  }, [text])

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      <span className="text-white/10">{text}</span>
      <span
        className="absolute inset-0 text-white overflow-hidden"
        style={{ width: `${(visibleChars / text.length) * 100}%` }}
      >
        {text}
      </span>
    </div>
  )
}
