"use client"

import { useEffect, useRef, useState, type ReactNode } from "react"

interface ScrollSectionWrapperProps {
  children: ReactNode
  animation?: "fade-up" | "fade-left" | "fade-right" | "scale" | "blur"
  delay?: number
  className?: string
}

export default function ScrollSectionWrapper({
  children,
  animation = "fade-up",
  delay = 0,
  className = "",
}: ScrollSectionWrapperProps) {
  const [isVisible, setIsVisible] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay * 1000)
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [delay])

  const getAnimationClasses = () => {
    const base = "transition-all duration-700 ease-out"
    const hidden = {
      "fade-up": "opacity-0 translate-y-12",
      "fade-left": "opacity-0 -translate-x-12",
      "fade-right": "opacity-0 translate-x-12",
      scale: "opacity-0 scale-90",
      blur: "opacity-0 blur-sm",
    }
    const visible = "opacity-100 translate-y-0 translate-x-0 scale-100 blur-0"

    return `${base} ${isVisible ? visible : hidden[animation]}`
  }

  return (
    <div ref={ref} className={`${getAnimationClasses()} ${className}`}>
      {children}
    </div>
  )
}
