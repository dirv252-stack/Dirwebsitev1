"use client"

import { useState, useEffect } from "react"

export default function CinematicLoader({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<"glitch" | "reveal" | "fade">("glitch")
  const [glitchText, setGlitchText] = useState("DIR")

  const glitchChars = "!@#$%^&*()_+-=[]{}|;':\",./<>?"

  useEffect(() => {
    // Glitch effect phase
    const glitchInterval = setInterval(() => {
      setGlitchText(
        "DIR"
          .split("")
          .map((char, i) => (Math.random() > 0.5 ? glitchChars[Math.floor(Math.random() * glitchChars.length)] : char))
          .join(""),
      )
    }, 50)

    // Phase transitions
    const revealTimer = setTimeout(() => {
      clearInterval(glitchInterval)
      setGlitchText("DIR")
      setPhase("reveal")
    }, 1200)

    const fadeTimer = setTimeout(() => {
      setPhase("fade")
    }, 2200)

    const completeTimer = setTimeout(() => {
      onComplete()
    }, 2800)

    return () => {
      clearInterval(glitchInterval)
      clearTimeout(revealTimer)
      clearTimeout(fadeTimer)
      clearTimeout(completeTimer)
    }
  }, [onComplete])

  return (
    <div
      className={`fixed inset-0 z-[100] bg-[#020202] flex items-center justify-center transition-opacity duration-500 ${phase === "fade" ? "opacity-0 pointer-events-none" : "opacity-100"}`}
    >
      {/* Scan lines overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-10">
        <div
          className="w-full h-full"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 229, 255, 0.03) 2px, rgba(0, 229, 255, 0.03) 4px)",
          }}
        />
      </div>

      {/* Glitch lines */}
      {phase === "glitch" && (
        <>
          <div
            className="absolute top-1/3 left-0 right-0 h-[2px] bg-cyan-400/50 animate-pulse"
            style={{ transform: `translateX(${Math.random() * 20 - 10}px)` }}
          />
          <div
            className="absolute top-2/3 left-0 right-0 h-[1px] bg-cyan-400/30 animate-pulse"
            style={{ transform: `translateX(${Math.random() * 20 - 10}px)` }}
          />
        </>
      )}

      {/* Main text */}
      <div className="relative">
        <h1
          className={`text-6xl md:text-8xl font-bold tracking-[0.3em] transition-all duration-500 ${
            phase === "glitch" ? "text-cyan-400 blur-[1px]" : "text-white"
          }`}
          style={{
            textShadow:
              phase === "reveal"
                ? "0 0 30px rgba(0, 229, 255, 0.8), 0 0 60px rgba(0, 229, 255, 0.5), 0 0 90px rgba(0, 229, 255, 0.3)"
                : "0 0 10px rgba(0, 229, 255, 0.5)",
          }}
        >
          {glitchText}
        </h1>

        {/* Underline reveal */}
        <div
          className={`h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent mt-4 transition-all duration-700 ${
            phase === "reveal" ? "w-full opacity-100" : "w-0 opacity-0"
          }`}
          style={{ margin: "0 auto" }}
        />

        {/* Subtitle */}
        <p
          className={`text-center text-cyan-400/60 text-sm tracking-[0.5em] mt-6 uppercase transition-all duration-500 ${
            phase === "reveal" ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
          }`}
        >
          Initializing
        </p>
      </div>

      {/* Corner decorations */}
      <div className="absolute top-8 left-8 w-16 h-16 border-l-2 border-t-2 border-cyan-400/30" />
      <div className="absolute top-8 right-8 w-16 h-16 border-r-2 border-t-2 border-cyan-400/30" />
      <div className="absolute bottom-8 left-8 w-16 h-16 border-l-2 border-b-2 border-cyan-400/30" />
      <div className="absolute bottom-8 right-8 w-16 h-16 border-r-2 border-b-2 border-cyan-400/30" />
    </div>
  )
}
