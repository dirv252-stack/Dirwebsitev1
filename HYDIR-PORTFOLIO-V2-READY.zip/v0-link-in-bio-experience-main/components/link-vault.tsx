"use client"

import { MessageCircle, Phone, Instagram, Music, Github, Twitter, Send } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const links = [
  {
    name: "WhatsApp Channel",
    url: "https://whatsapp.com/channel/0029VbARvAxJENyAyjxbhK2i",
    icon: MessageCircle,
    color: "hover:border-green-500 hover:shadow-[0_0_40px_rgba(34,197,94,0.3)]",
  },
  {
    name: "Copy Phone",
    url: "62895401999318",
    icon: Phone,
    color: "hover:border-blue-500 hover:shadow-[0_0_40px_rgba(59,130,246,0.3)]",
    isCopy: true,
  },
  {
    name: "Instagram",
    url: "https://www.instagram.com/dirnust",
    icon: Instagram,
    color: "hover:border-pink-500 hover:shadow-[0_0_40px_rgba(236,72,153,0.3)]",
  },
  {
    name: "TikTok",
    url: "https://www.tiktok.com/@dirneedlove",
    icon: Music,
    color: "hover:border-white hover:shadow-[0_0_40px_rgba(255,255,255,0.3)]",
  },
  {
    name: "GitHub",
    url: "https://github.com/dirv252-stack",
    icon: Github,
    color: "hover:border-primary hover:shadow-[0_0_60px_rgba(0,229,255,0.5)] border-primary/50",
    isSpecial: true,
  },
  {
    name: "Twitter/X",
    url: "https://x.com/DirV267798",
    icon: Twitter,
    color: "hover:border-blue-400 hover:shadow-[0_0_40px_rgba(96,165,250,0.3)]",
  },
  {
    name: "Telegram",
    url: "@dircolado",
    icon: Send,
    color: "hover:border-blue-500 hover:shadow-[0_0_40px_rgba(59,130,246,0.3)]",
  },
]

export default function LinkVault() {
  const { toast } = useToast()

  const handleClick = (link: (typeof links)[0]) => {
    if (link.isCopy) {
      navigator.clipboard.writeText(link.url)
      toast({
        title: "Copied to clipboard",
        description: `Phone number ${link.url} has been copied`,
      })
    } else {
      window.open(link.url.startsWith("@") ? `https://t.me/${link.url.slice(1)}` : link.url, "_blank")
    }
  }

  return (
    <section className="relative py-32 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-white tracking-wider">THE LINK VAULT</h2>
        <p className="text-center text-muted-foreground mb-16 tracking-widest text-sm">CONNECT WITH ME</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {links.map((link) => {
            const Icon = link.icon
            return (
              <button
                key={link.name}
                onClick={() => handleClick(link)}
                className={`
                  glassmorphism p-6 rounded-2xl flex items-center gap-4
                  transition-all duration-300 hover:scale-105
                  ${link.color}
                  ${link.isSpecial ? "border-2" : "border"}
                  group cursor-pointer
                `}
              >
                <div
                  className={`
                  w-12 h-12 rounded-xl flex items-center justify-center
                  ${link.isSpecial ? "bg-primary/20" : "bg-secondary"}
                  group-hover:bg-primary/30 transition-colors
                `}
                >
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <div className="text-left flex-1">
                  <h3 className="text-lg font-semibold text-white">{link.name}</h3>
                  <p className="text-sm text-muted-foreground">{link.isCopy ? "Click to copy" : "Click to visit"}</p>
                </div>
              </button>
            )
          })}
        </div>
      </div>
    </section>
  )
}
