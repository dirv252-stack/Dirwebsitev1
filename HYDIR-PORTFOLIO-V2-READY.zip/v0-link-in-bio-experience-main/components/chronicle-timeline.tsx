"use client"

import { useEffect, useRef, useState } from "react"
import { Circle, Zap } from "lucide-react"

const timeline = [
  { title: "Genesis", description: "2 Months Ago", detail: "The journey begins with curiosity" },
  { title: "Mastering Logic", description: "Present", detail: "Building unbreakable foundations" },
  { title: "Building This Digital Realm", description: "Ongoing", detail: "Crafting immersive experiences" },
]

export default function ChronicleTimeline() {
  const [visibleItems, setVisibleItems] = useState<boolean[]>(new Array(timeline.length).fill(false))
  const [scrollProgress, setScrollProgress] = useState(0)
  const itemRefs = useRef<(HTMLDivElement | null)[]>([])
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let ticking = false

    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          if (!sectionRef.current) return
          const rect = sectionRef.current.getBoundingClientRect()
          const windowHeight = window.innerHeight
          const progress = Math.max(0, Math.min(1, (windowHeight - rect.top) / (windowHeight + rect.height / 2)))
          setScrollProgress(progress)
          ticking = false
        })
        ticking = true
      }
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    handleScroll()

    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const observers = itemRefs.current.map((ref, index) => {
      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setVisibleItems((prev) => {
              const newVisible = [...prev]
              newVisible[index] = true
              return newVisible
            })
          }
        },
        { threshold: 0.2 },
      )

      if (ref) observer.observe(ref)
      return observer
    })

    return () => observers.forEach((observer) => observer.disconnect())
  }, [])

  return (
    <section ref={sectionRef} className="relative py-32 px-4 overflow-hidden">
      <div className="max-w-4xl mx-auto relative">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-white tracking-wider">CHRONICLE</h2>
        <p className="text-center text-muted-foreground mb-16 tracking-widest text-sm">THE JOURNEY</p>

        <div className="relative">
          {/* Background line */}
          <div className="absolute left-8 md:left-1/2 md:-translate-x-px top-0 bottom-0 w-0.5 bg-gray-800/50" />

          {/* Progress line */}
          <div
            className="absolute left-8 md:left-1/2 md:-translate-x-px top-0 w-0.5 bg-primary shadow-[0_0_10px_rgba(0,229,255,0.5)]"
            style={{ height: `${scrollProgress * 100}%` }}
          />

          <div className="space-y-16">
            {timeline.map((item, index) => (
              <div
                key={index}
                ref={(el) => {
                  itemRefs.current[index] = el
                }}
                className={`
                  relative flex flex-col md:flex-row items-start md:items-center gap-8 pl-16 md:pl-0
                  transition-all duration-700 ease-out
                  ${visibleItems[index] ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}
                `}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                {/* Card */}
                <div className={`flex-1 ${index % 2 === 0 ? "md:text-right md:pr-12" : "md:order-2 md:pl-12"}`}>
                  <div className="group glassmorphism p-6 rounded-2xl transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]">
                    <div className="flex items-start gap-3">
                      <Zap
                        className={`w-5 h-5 text-primary mt-1 flex-shrink-0 ${index % 2 === 0 ? "md:order-2" : ""}`}
                      />
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-white mb-1 group-hover:text-primary transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-primary font-medium text-sm tracking-wider mb-1">{item.description}</p>
                        <p className="text-muted-foreground text-sm">{item.detail}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Dot */}
                <div className="absolute left-8 md:left-1/2 -translate-x-1/2 z-10">
                  <div
                    className={`
                      w-6 h-6 rounded-full bg-primary flex items-center justify-center
                      transition-all duration-500
                      ${visibleItems[index] ? "scale-100 shadow-[0_0_15px_rgba(0,229,255,0.6)]" : "scale-0"}
                    `}
                    style={{ transitionDelay: `${index * 100 + 200}ms` }}
                  >
                    <Circle className="w-3 h-3 text-white fill-white" />
                  </div>
                </div>

                <div className={`flex-1 hidden md:block ${index % 2 === 0 ? "md:order-2" : ""}`} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
