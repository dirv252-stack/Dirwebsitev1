"use client"

import { useEffect, useState } from "react"

const quotes = [
  "Code is poetry written in logic",
  "Curiosity fuels innovation",
  "Every bug is a lesson in disguise",
  "Design is not just what it looks like, but how it works",
  "The best way to predict the future is to build it",
]

export default function InfiniteThoughts() {
  const [currentQuote, setCurrentQuote] = useState(0)
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setIsVisible(false)
      setTimeout(() => {
        setCurrentQuote((prev) => (prev + 1) % quotes.length)
        setIsVisible(true)
      }, 500)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <section className="relative py-32 px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-4 text-white tracking-wider">INFINITE THOUGHTS</h2>
        <p className="text-center text-muted-foreground mb-16 tracking-widest text-sm">WISDOM ROTATOR</p>

        <div className="glassmorphism p-12 md:p-16 rounded-2xl min-h-[200px] flex items-center justify-center">
          <blockquote
            className={`
              text-2xl md:text-3xl text-center text-white font-light leading-relaxed
              transition-all duration-500
              ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}
            `}
          >
            &quot;{quotes[currentQuote]}&quot;
          </blockquote>
        </div>
      </div>
    </section>
  )
}
