"use client"

import { useEffect, useRef, useState } from "react"
import { Sparkles, BadgeCheck, Shield, Star, Crown, Zap, Heart, Award, Gem } from "lucide-react"

export default function BestPartnerFooter() {
  const [isVisible, setIsVisible] = useState(false)
  const [revealedLetters, setRevealedLetters] = useState(0)
  const [clickCount, setClickCount] = useState(0)
  const [showEasterEgg, setShowEasterEgg] = useState(false)
  const [typingText, setTypingText] = useState("")
  const [typingIndex, setTypingIndex] = useState(0)
  const [isDeleting, setIsDeleting] = useState(false)
  const [scrollY, setScrollY] = useState(0)
  const sectionRef = useRef<HTMLDivElement>(null)
  const name = "JEVANO DEVENTER"

  const typingPhrases = ["BEST PARTNER", "BESTFRIEND", "IMPORTANT PERSON"]

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }
    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true)
      },
      { threshold: 0.3 },
    )

    if (sectionRef.current) observer.observe(sectionRef.current)
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    if (isVisible && revealedLetters < name.length) {
      const timeout = setTimeout(() => setRevealedLetters((prev) => prev + 1), 100)
      return () => clearTimeout(timeout)
    }
  }, [isVisible, revealedLetters])

  const handleNameClick = () => {
    const newCount = clickCount + 1
    setClickCount(newCount)
    if (newCount >= 7) {
      setShowEasterEgg(true)
      setClickCount(0)
    }
  }

  useEffect(() => {
    if (!isVisible) return

    const currentPhrase = typingPhrases[typingIndex % typingPhrases.length]

    const timeout = setTimeout(
      () => {
        if (!isDeleting) {
          if (typingText.length < currentPhrase.length) {
            setTypingText(currentPhrase.slice(0, typingText.length + 1))
          } else {
            setTimeout(() => setIsDeleting(true), 2000)
          }
        } else {
          if (typingText.length > 0) {
            setTypingText(typingText.slice(0, -1))
          } else {
            setIsDeleting(false)
            setTypingIndex((prev) => prev + 1)
          }
        }
      },
      isDeleting ? 50 : 100,
    )

    return () => clearTimeout(timeout)
  }, [isVisible, typingText, isDeleting, typingIndex])

  return (
    <section ref={sectionRef} className="relative py-32 px-4 overflow-hidden">
      {/* Easter Egg Modal */}
      {showEasterEgg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-cyan-500/50 rounded-2xl p-8 max-w-sm mx-4 text-center animate-fade-in-scale">
            <Sparkles className="w-12 h-12 text-cyan-400 mx-auto mb-4 animate-pulse" />
            <h3 className="text-xl font-bold text-white mb-2">SELAMAT!</h3>
            <p className="text-cyan-300 mb-6">Kamu dipilih! Hubungi admin untuk claim hadiah</p>
            <button
              onClick={() => setShowEasterEgg(false)}
              className="px-6 py-2 bg-cyan-500 hover:bg-cyan-400 text-black font-medium rounded-lg transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      <div
        className="absolute inset-0 bg-gradient-to-t from-cyan-500/10 via-cyan-500/5 to-transparent animate-pulse-slow"
        style={{ transform: `translateY(${scrollY * 0.05}px)` }}
      />

      <div
        className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl animate-pulse-slow"
        style={{ transform: `translate(${scrollY * 0.03}px, ${scrollY * -0.02}px)` }}
      />
      <div
        className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl animate-pulse-slow"
        style={{
          transform: `translate(${scrollY * -0.03}px, ${scrollY * 0.02}px)`,
          animationDelay: "1s",
        }}
      />

      <div
        className="max-w-2xl mx-auto text-center relative z-10"
        style={{ transform: `translateY(${scrollY * -0.02}px)` }}
      >
        {/* Version and @dir badges */}
        <div
          className={`flex items-center justify-center gap-3 mb-8 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
        >
          <span className="px-3 py-1.5 bg-purple-500/20 border border-purple-500/40 rounded-full text-purple-300 text-xs flex items-center gap-1.5 hover:bg-purple-500/30 hover:scale-105 transition-all cursor-default shadow-lg shadow-purple-500/20">
            <Gem className="w-3.5 h-3.5" />
            v1.4
          </span>
          <span className="px-3 py-1.5 bg-red-500/20 border border-red-500/40 rounded-full text-red-300 text-xs flex items-center gap-1.5 hover:bg-red-500/30 hover:scale-105 transition-all cursor-default shadow-lg shadow-red-500/20">
            @dir
            <BadgeCheck className="w-3.5 h-3.5 fill-red-400" />
          </span>
        </div>

        {/* Typing text */}
        <p
          className={`text-cyan-400 text-sm tracking-[0.3em] uppercase mb-6 h-6 transition-all duration-700 delay-200 ${isVisible ? "opacity-100" : "opacity-0"}`}
        >
          {typingText}
          <span className="inline-block w-0.5 h-4 bg-cyan-400 ml-1 animate-pulse" />
        </p>

        <h2
          className="text-4xl md:text-6xl font-bold mb-10 cursor-pointer animate-float"
          onClick={handleNameClick}
          style={{ animationDuration: "5s" }}
        >
          {name.split("").map((letter, index) => (
            <span
              key={index}
              className={`inline-block transition-all duration-500 ${
                index < revealedLetters
                  ? "opacity-100 translate-y-0 text-white animate-breathe"
                  : "opacity-0 translate-y-4"
              }`}
              style={{
                transitionDelay: `${index * 80}ms`,
                animationDelay: `${index * 100}ms`,
              }}
            >
              {letter === " " ? "\u00A0" : letter}
            </span>
          ))}
        </h2>

        <div
          className={`flex flex-wrap justify-center gap-2 mb-10 transition-all duration-700 delay-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
        >
          <span
            className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 bg-yellow-500/20 border border-yellow-500/40 text-yellow-300 hover:bg-yellow-500/30 hover:scale-110 hover:shadow-lg hover:shadow-yellow-500/30 transition-all duration-300 cursor-default"
            style={{ animationDelay: "0ms" }}
          >
            <Crown className="w-3.5 h-3.5" />
            VIP Partner
          </span>
          <span
            className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/30 hover:scale-110 hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300 cursor-default"
            style={{ animationDelay: "100ms" }}
          >
            <Shield className="w-3.5 h-3.5" />
            Trusted
          </span>
          <span
            className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 bg-pink-500/20 border border-pink-500/40 text-pink-300 hover:bg-pink-500/30 hover:scale-110 hover:shadow-lg hover:shadow-pink-500/30 transition-all duration-300 cursor-default"
            style={{ animationDelay: "200ms" }}
          >
            <Heart className="w-3.5 h-3.5" />
            Loyal
          </span>
          <span
            className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 bg-green-500/20 border border-green-500/40 text-green-300 hover:bg-green-500/30 hover:scale-110 hover:shadow-lg hover:shadow-green-500/30 transition-all duration-300 cursor-default"
            style={{ animationDelay: "300ms" }}
          >
            <Star className="w-3.5 h-3.5" />5 Star
          </span>
          <span
            className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 bg-orange-500/20 border border-orange-500/40 text-orange-300 hover:bg-orange-500/30 hover:scale-110 hover:shadow-lg hover:shadow-orange-500/30 transition-all duration-300 cursor-default"
            style={{ animationDelay: "400ms" }}
          >
            <Zap className="w-3.5 h-3.5" />
            Elite
          </span>
          <span
            className="px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 hover:bg-indigo-500/30 hover:scale-110 hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-300 cursor-default"
            style={{ animationDelay: "500ms" }}
          >
            <Award className="w-3.5 h-3.5" />
            Legend
          </span>
        </div>

        <div
          className={`h-px w-48 mx-auto bg-gradient-to-r from-transparent via-cyan-500/70 to-transparent transition-all duration-1000 delay-700 ${isVisible ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"}`}
        />

        <p
          className={`text-zinc-500 text-xs mt-8 tracking-widest transition-all duration-700 delay-1000 ${isVisible ? "opacity-100" : "opacity-0"}`}
        >
          CRAFTED WITH PASSION
        </p>
      </div>
    </section>
  )
}
