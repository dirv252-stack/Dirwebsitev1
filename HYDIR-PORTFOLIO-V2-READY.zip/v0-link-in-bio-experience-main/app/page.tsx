"use client"

import { useState } from "react"
import dynamic from "next/dynamic"
import ParticlesBackground  from "@/components/particles-background"
import HeroSection          from "@/components/hero-section"
import SkillLab             from "@/components/skill-lab"
import ChronicleTimeline    from "@/components/chronicle-timeline"
import InfiniteThoughts     from "@/components/infinite-thoughts"
import LinkVault            from "@/components/link-vault"
import BestPartnerFooter    from "@/components/best-partner-footer"
import TechStackGrid        from "@/components/tech-stack-grid"
import ScrollSectionWrapper from "@/components/scroll-section-wrapper"
import TerminalCLI          from "@/components/terminal-cli"
import AnonymousZone        from "@/components/anonymous-zone"
import MiniLibrary          from "@/components/mini-library"

const CinematicLoader = dynamic(() => import("@/components/cinematic-loader"), { ssr: false })

export default function Home() {
  const [showLoader, setShowLoader] = useState(true)

  return (
    <main className="relative min-h-screen overflow-x-hidden bg-[#020202]">
      {showLoader && <CinematicLoader onComplete={() => setShowLoader(false)} />}
      <ParticlesBackground />
      <div className={`relative z-10 transition-opacity duration-500 ${showLoader ? "opacity-0" : "opacity-100"}`}>
        <ScrollSectionWrapper animation="fade-up">
          <HeroSection />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="scale" delay={0.1}>
          <TechStackGrid />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="fade-left" delay={0.1}>
          <SkillLab />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="fade-up" delay={0.1}>
          <TerminalCLI />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="fade-right" delay={0.1}>
          <MiniLibrary />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="blur" delay={0.1}>
          <AnonymousZone />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="fade-right" delay={0.1}>
          <ChronicleTimeline />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="blur" delay={0.1}>
          <InfiniteThoughts />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="fade-up" delay={0.1}>
          <LinkVault />
        </ScrollSectionWrapper>
        <ScrollSectionWrapper animation="scale" delay={0.2}>
          <BestPartnerFooter />
        </ScrollSectionWrapper>
      </div>
    </main>
  )
}
